#include <tiny13a.h>  
#include <delay.h>
unsigned int tic, Dimmer=1000;
interrupt [EXT_INT0] void ext_int0_isr(void){
  tic=0;
  TCNT0=0x00; 
  PORTB.2=1;
 }
interrupt [TIM0_COMPA] void timer0_compa_isr(){
  tic++;  
  if (tic>Dimmer){ tic=0;
    PORTB.2=0;  
 } 
} 
void main(void)
{  
CLKPR=0x80;
CLKPR=0x00;
PORTB=0x21;
DDRB=0x04;
TCCR0A=0x02;
TCCR0B=0x02;
TCNT0=0x00;
OCR0A=0x0B;
OCR0B=0x00;
GIMSK=0x40;
MCUCR=0x03;
GIFR=0x40;
TIMSK0=0x04; 
#asm("sei")
while (1)
      {        
      while(!PINB.0 & Dimmer<1000)
      {
          Dimmer++;
          delay_ms(10);
      }
      while(!PINB.5 & Dimmer>500)
      {
          Dimmer--;
          delay_ms(10);

      };      
 }
}