/* �������� ���������� ���� ����� 10�
   Chip type               : ATtiny13A
   AVR Core Clock frequency: 9,600000 MHz
*/
#include <tiny13a.h>  
#include <delay.h>
unsigned int tic, Dimmer=600;
unsigned char p=0;
bit flag=0;
interrupt [EXT_INT0] void ext_int0_isr(void){
  tic=0;
  TCNT0=0x00; 
  PORTB.2=1;
 }
interrupt [TIM0_COMPA] void timer0_compa_isr(){
  tic++;  
  if (tic>Dimmer+400){ tic=0;
    PORTB.2=0;  
 } 
} 
void main(void){  
CLKPR=0x80;
CLKPR=0x00;
PORTB=0x19;
DDRB=0x24;
TCCR0A=0x02;
TCCR0B=0x02;
TCNT0=0x00;
OCR0A=0x0B;
OCR0B=0x00;
GIMSK=0x40;
MCUCR=0x03;
GIFR=0x40;
TIMSK0=0x04; 
#asm("sei")
while (1)
  {    if(PINB.0==1 && flag==1) flag=0; 
       if(PINB.0==0 && flag==0){flag=1; p++; if (p>9) p=0; PORTB.5=0; delay_ms(200);}              
       switch (p) {        
       case 1: Dimmer=270; PORTB.5=1; break;
       case 2: Dimmer=235; PORTB.5=1; break;
       case 3: Dimmer=200; PORTB.5=1; break;            
       case 4: Dimmer=165; PORTB.5=1; break; 
       case 5: Dimmer=130;  PORTB.5=1; break; 
       case 6: Dimmer=95;  PORTB.5=1; break; 
       case 7: Dimmer=60;  PORTB.5=1; break; 
       case 8: Dimmer=30;   PORTB.5=1; break; 
       case 9: Dimmer=0;   PORTB.5=1; break;
       default: PORTB.5=0; Dimmer=600; break;        
       }
  }
}